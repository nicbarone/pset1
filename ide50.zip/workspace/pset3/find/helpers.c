/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{
    int ending = n-1;
    int begginning = 0;
    
    while( ending >= beggining)
    {
        int middle = (beggining + ending) / 2;
        if(values[middle] == value)
        return true;
        else if(values[middle] > value)
        ending = middle - 1;
        else
        beggining = middle + 1;
    }
        return false;
    }
    // TODO: implement a searching algorithm
    


/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    for( int i = 1; i < n - 1; i++)
    {
        int temporary = 0;
        int min = i;
        for(int j = i + 1; j < n; j++)
        {
            if(values[j] < values[min])
            {
                min = j;
            }
            temporary = values[min];
            values[min] = values[i];
            values[i] = temporary;
        }
    }
    // TODO: implement an O(n^2) sorting algorithm
    return;
}