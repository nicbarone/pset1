/**
 * generate.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Generates pseudorandom numbers in [0,LIMIT), one per line.
 *
 * Usage: generate n [s]
 *
 * where n is number of pseudorandom numbers to print
 * and s is an optional seed
 */
 
#define _XOPEN_SOURCE

#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// constant
#define LIMIT 65536

int main(int argc, string argv[])
{
    // take a command line argument and make sure it is two or three command line inputs
    if (argc != 2 && argc != 3)
    {
        printf("Usage: generate n [s]\n");
        return 1;
    }

    // display error and state format for input
    int n = atoi(argv[1]);

    // retrieve command line argument and converts into integer from an ascii value
    //if there are three command line arguments then convert the third
    //
    if (argc == 3)
    {
        srand48((long int) atoi(argv[2]));
    }
    else
    {
        srand48((long int) time(NULL));
    }

    // use srand48 function to initiatilize drand48 function
    for (int i = 0; i < n; i++)
    {
        printf("%i\n", (int) (drand48() * LIMIT));
    }
    // drand48 function generates a sequence of 48-bit integers and returns nonnegative double-precision floating-point values between 0-1
    // generates random numbers n number of times

    // success
    return 0;
}