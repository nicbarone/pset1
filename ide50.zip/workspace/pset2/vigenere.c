#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, string argv[])
{
bool success = false;
string keyword = "";

  do 
  {
  if(argc != 2)
  {
    printf("must be less than two arguments and cannot be digits\n");
    
    return 1;
  }
  else if(argv[1])
  {
    int length = strlen(argv[1]);
    for( int i= 0; i < length; i++)
    {
      if(!isalpha(argv[1][i]))
      {
        printf("your inuopt contains illegal characters");
        return 1;
      }
      else 
      {
        success = true;
         keyword = argv[1];
      }
      
    }
  }
  }
  while(!success);
  // determines if the user has put in wrong input by not entering numbers as a key or putting multiple keys
  
 
 // retreives key and checks if positive 
  string plaintext = GetString();
  
  // retrives plaintext and stores it 
  for (int i = 0, j = 0, n = strlen(plaintext); i < n; i++)
  {
  
  
  // loops function in order for caculation to continue for as long as the plaintext is 
  
    int letterKey = tolower(keyword[j % strlen(keyword)]) - 'a';
    // loops keyword length with modulo function in order to correclty encrypt text by looping back around
    
    if (isalpha(plaintext[i]))
    // checks if a letter
    //then checks if upper or lower case to preserve captitilization 
  {
    if( isupper(plaintext[i]))
    {
      int result = ((plaintext[i] - 'A' + letterKey)%26 + 'A');
      j++;
      
      printf("%c",result);
    }
    if( islower(plaintext[i]))
    {
      int result = ((plaintext[i] - 'a' + letterKey)%26 + 'a');
      j++;
      
    
     
      printf("%c",result);
    }
    
    
  // subtracts beggining capitilized or lower case value then adds key finds remainder re-adds value to allow for looping construct
  }
  
else 
{
printf("%c", plaintext[i]);

}
}
printf("\n");
return 0;
// prints and finishes program

}