#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(void)
{

    
    string name = GetString();
    printf("%c", toupper(name[0]));
    // retrieves and prints begginning letter of user input in capitilized form
    
    for( int i = 0, s = strlen(name); i <= s; i++)
    //for loop goes through letters of users name
    {
        if(name[i] == ' ')
        {
        printf("%c", toupper(name[i + 1]));
        }
    }
    //checks when a space is presented then prints letter after the space 
    printf("\n");
    // prints space and gives initials of user
    
}