#include <stdio.h>
#include <cs50.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, string argv[])
{
  
  if(argc != 2 && !isdigit(argv[1]))
  {
    printf("too many arguments, must be less than two\n");
    
    return 1;
  }
  // determines if the user has put in wrong input by not entering numbers as a key or putting multiple keys
 int key = atoi(argv[1]);
 if(key < 0)
 {  
   printf("not valid input must be positive\n");
   return 1;
 }
 // retreives key and checks if positive 
  string plaintext = GetString();
  // retrives plaintext and stores it 
  for (int i = 0, n = strlen(plaintext); i < n; i++)
  // loops function in order for caculation to continue for as long as the plaintext is 
  {
    if (isalpha(plaintext[i]))
    // checks if a letter
    //then checks if upper or lower case to preserve captitilization 
  {
    if( isupper(plaintext[i]))
    {
      int result = (((plaintext[i] + key+'A')%26) + 'A');
      printf("%c",result);
    }
    if( islower(plaintext[i]))
    {
      int result = (((plaintext[i] + key-'a')%26) + 'a');
      printf("%c",result);
    }
  // subtracts beggining capitilized or lower case value then adds key finds remainder re-adds value to allow for looping construct
  }
else 
{
printf("%c", plaintext[i]);
}
}
printf("\n");
return 0;
// prints and finishes program
}
