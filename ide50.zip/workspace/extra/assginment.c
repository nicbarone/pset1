#include <cs50.h>
#include<stdio.h>
int main(void)
{
    printf("Give me a positive number: ");
    int n = GetFloat();
    if(n < 0)
    {
    printf("must be positive!");
    return 1;
    }
    for(int i = 0; i < n; i++)
    if( n > 0)
    {
        int result = (i;
        printf("%d", result);
        return 0;
         printf("\n");
    }
   
}