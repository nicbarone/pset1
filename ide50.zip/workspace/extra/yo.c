#include <stdio.h>
#include <cs50.h>
#include <string.h>
int sigma( int n);
int main(void)
{
    int n;
    do
    {
    printf("give me a positive int: ");
    n = GetInt();
}
while( n< 1);
int answer= sigma(n);
    printf("your sum is %i\n", answer);
    
}
int sigma( int m)
{
if( m<1)
{
    return 0;
}
else 
{
return m + sigma(m-1);
}
}
