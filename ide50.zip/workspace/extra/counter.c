#include <cs50.h>
#include <stdio.h>

void f()
{
    printf("hello world\n");
}
int main(void)
{
    printf("give me a number: ");
    int num = GetInt();
    num = (num / 2) + 1;
    
    for (int i = 0; i < num; i++)
    {
        printf("%i!\n", i);
    }
}