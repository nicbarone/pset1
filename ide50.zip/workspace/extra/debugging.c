#include <cs50.h>
int main( int argc, string argv[])
{
    int counter = 1;
    for( int i =1; i < 12; i++)
    {
        counter *= i;
    }
    return 0;
}